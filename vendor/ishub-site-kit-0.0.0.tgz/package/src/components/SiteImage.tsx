/**
 * The one <img> the Israeli fleet is allowed to render.
 *
 * Same contract as the USA kit's SiteImage, with one deliberate difference: `preferHebrewAlt`
 * DEFAULTS TO TRUE here. Every site in this fleet is he-IL / RTL, so Hebrew is the alt text that
 * actually ships; making the caller opt in would mean 50+ call sites passing a flag and any one
 * of them silently shipping English alt to a Hebrew page.
 *
 * Server component: no hooks, no "use client", no client JS. Emits a plain <img> because every
 * site is output:"export" with images.unoptimized:true. It is safe to use inside a client
 * component (Header), but it must NOT carry its own "use client" directive or it would drag
 * every server component that uses it into the client bundle.
 *
 * Rules baked in and not overridable:
 *   - alt is structurally required. alt="" is a COMPILE error; genuinely decorative art must
 *     pass `decorative` so the intent is explicit and reviewable.
 *   - width + height are always emitted -> zero CLS.
 *   - priority  -> fetchpriority=high + eager   (LCP; exactly one per page)
 *     otherwise -> loading=lazy + decoding=async
 *   - SVG is NEVER sent through /cdn-cgi/image - Cloudflare does not rasterize it.
 *   - A local src (leading "/") is served verbatim with no srcset: a static export has no
 *     resizer, so advertising widths the origin cannot produce would be a lie.
 */
import type { CSSProperties } from "react";
import type { ImageRef, SiteImages } from "../media/types";
import { srcFor, srcsetFor, isVector, isLocalPath } from "../media/url";

/** alt="" is a type error. This is the whole point. */
type NonEmpty<S extends string> = S extends "" ? never : S;

interface BaseProps {
  /** The site's images block. Pass `manifest.images`. */
  images?: SiteImages | null;
  /**
   * Responsive `sizes`. REQUIRED for fluid images - a wrong or absent `sizes` makes the whole
   * srcset useless, because the browser then assumes 100vw. Ignored when `fixed`.
   */
  sizes?: string;
  /** Renders into a CSS-fixed box (logos, badges): srcset is 1x/2x only, `sizes` is not emitted. */
  fixed?: boolean;
  /** LCP candidate. Exactly one per page. */
  priority?: boolean;
  fit?: "cover" | "contain" | "scale-down" | "crop" | "pad";
  quality?: number;
  className?: string;
  style?: CSSProperties;
}

/** Manifest-sourced: alt travels with the image and is validated in CI. */
interface FromRef extends BaseProps {
  image: ImageRef;
  /** Defaults to TRUE in this fleet. Set false only for an /en route. */
  preferHebrewAlt?: boolean;
  src?: never;
  alt?: never;
  width?: never;
  height?: never;
  decorative?: never;
}

/** Ad-hoc: alt is a required non-empty literal, checked by the compiler. */
interface AdHoc<A extends string> extends BaseProps {
  src: string;
  alt: NonEmpty<A>;
  width: number;
  height: number;
  image?: never;
  decorative?: never;
}

/** Explicitly decorative: renders alt="" plus aria-hidden. Must be opted into. */
interface Decorative extends BaseProps {
  src: string;
  decorative: true;
  width: number;
  height: number;
  image?: never;
  alt?: never;
}

export type SiteImageProps<A extends string = string> = FromRef | AdHoc<A> | Decorative;

export function SiteImage<A extends string>(props: SiteImageProps<A>) {
  const { images, sizes, fixed, priority, fit, quality, className, style } = props;

  const ref: ImageRef =
    "image" in props && props.image
      ? props.image
      : {
          key: (props as AdHoc<A> | Decorative).src,
          alt: "decorative" in props && props.decorative ? "" : ((props as AdHoc<A>).alt as string),
          width: (props as AdHoc<A> | Decorative).width,
          height: (props as AdHoc<A> | Decorative).height,
          kind: /\.svgz?$/i.test((props as AdHoc<A> | Decorative).src) ? "vector" : "raster",
        };

  const decorative = "decorative" in props && props.decorative === true;
  let alt: string;
  if (decorative) {
    alt = "";
  } else if ("image" in props && props.image) {
    // Hebrew first: this fleet is entirely RTL. Fall back to English only when there is no
    // Hebrew string at all, so a missing translation degrades rather than rendering empty.
    const preferHe = props.preferHebrewAlt !== false;
    alt = preferHe ? props.image.altHe || props.image.alt : props.image.alt || props.image.altHe || "";
  } else {
    alt = ref.alt;
  }

  const transformable = !isVector(ref) && !isLocalPath(ref.key) && !!images?.mediaHost;
  const srcSet = transformable ? srcsetFor(images, ref, { fixed, fit, quality }) : undefined;
  const src = srcFor(images, ref, { fit, quality });

  // The focal point also drives CSS so `object-fit: cover` crops the same way the CDN does.
  const focalStyle: CSSProperties | undefined = ref.focal
    ? { objectPosition: `${Math.round(ref.focal.x * 100)}% ${Math.round(ref.focal.y * 100)}%` }
    : undefined;

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      {...(srcSet ? { srcSet } : {})}
      {...(srcSet && !fixed && sizes ? { sizes } : {})}
      alt={alt}
      {...(decorative ? { "aria-hidden": true } : {})}
      width={ref.width}
      height={ref.height}
      {...(priority
        ? { fetchPriority: "high" as const, loading: "eager" as const, decoding: "async" as const }
        : { loading: "lazy" as const, decoding: "async" as const })}
      className={className}
      style={focalStyle ? { ...focalStyle, ...style } : style}
    />
  );
}
